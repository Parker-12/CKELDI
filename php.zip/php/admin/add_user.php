<?php
require '../config/database.php';
if($_POST)
{
 $pdo->prepare
 (
 "INSERT INTO utilisateurs VALUES(NULL,?,?,?,?,?)"
 )->execute([
 $_POST['prenom'],$_POST['nom'],$_POST['email'],
 sha1($_POST['mot_de_passe']),$_POST['role']
 ]);
 header('Location: utilisateurs.php');
}
?>
<form method="post">
<input name="prenom">
<input name="nom">
<input name="email">
<input name="mot_de_passe">
<select name="role">
<option>Administrateur</option>
<option>Utilisateur simple</option>
</select>
<button>Ajouter</button>
</form>
