<?php
require '../config/database.php';


if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'Administrateur')
{
    header('Location: ../index.php');
    exit;
}

require '../includes/header.php';


$nbUsers = $pdo->query("SELECT COUNT(*) FROM utilisateurs")->fetchColumn();
$nbTaches = $pdo->query("SELECT COUNT(*) FROM taches")->fetchColumn();
$nbEnCours = $pdo->query("SELECT COUNT(*) FROM taches WHERE statut='En cours'")->fetchColumn();
$nbTerminees = $pdo->query("SELECT COUNT(*) FROM taches WHERE statut='Terminée'")->fetchColumn();

$tachesParUser = $pdo->query
("
    SELECT u.prenom, u.nom, COUNT(t.id) AS total
    FROM utilisateurs u
    LEFT JOIN taches t ON u.id = t.utilisateur_id
    GROUP BY u.id
    ORDER BY total DESC
")->fetchAll();

$tauxCompletion = $nbTaches > 0 ? round(($nbTerminees / $nbTaches) * 100) : 0;
?>

<style>
    :root 
    {
        --primary: #4e73df;
        --secondary: #858796;
        --success: #1cc88a;
        --info: #36b9cc;
        --warning: #f6c23e;
        --danger: #e74a3b;
        --dark-grad: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
    }

    body 
    {  
      background: linear-gradient(135deg, #f9fafb 0%, #eef2ff 33%,#ecfeff 66%, #f8fafc 100% );
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      font-style: italic;
      min-height: 100vh; 
    }

    
    .dashboard-header 
    {
        background: var(--dark-grad);
        color: white;
        padding: 2.5rem;
        border-radius: 20px;
        margin-bottom: 2.5rem;
        box-shadow: 0 10px 25px rgba(78, 115, 223, 0.2);
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    
    .stat-card 
    {
        border: none;
        border-radius: 16px;
        padding: 1.5rem;
        background: white;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        border-left: 5px solid transparent;
    }

    .stat-card:hover 
    {
        transform: translateY(-10px);
        box-shadow: 0 1rem 3rem rgba(0,0,0,0.1);
    }

    .card-users { border-left-color: var(--primary); }
    .card-tasks { border-left-color: var(--info); }
    .card-pending { border-left-color: var(--warning); }
    .card-done { border-left-color: var(--success); }

    .stat-title 
    {
        font-size: 0.75rem;
        font-weight: bold;
        color: var(--secondary);
        text-transform: uppercase;
        margin-bottom: 0.5rem;
    }

    .stat-value 
    {
        font-size: 1.8rem;
        font-weight: 700;
        color: #5a5c69;
    }

    .stat-icon 
    {
        font-size: 2rem;
        color: #dddfeb;
        position: absolute;
        right: 1.5rem;
        top: 50%;
        transform: translateY(-50%);
    }

    
    .glass-panel 
    {
        background: white;
        border-radius: 20px;
        padding: 2rem;
        box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        margin-bottom: 2rem;
    }

    .progress 
    {
        height: 1.2rem;
        border-radius: 10px;
        background-color: #eaecf4;
        box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
    }

    /* Table Design */
    .modern-table 
    {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 10px;
    }

    .modern-table thead th 
    {
        border: none;
        color: var(--secondary);
        font-weight: 600;
        padding: 1rem;
    }

    .modern-table tbody tr 
    {
        background: white;
        box-shadow: 0 2px 10px rgba(0,0,0,0.03);
        border-radius: 10px;
    }

    .modern-table td 
    {
        padding: 1.2rem;
        vertical-align: middle;
        border: none;
    }

    .modern-table td:first-child { border-radius: 10px 0 0 10px; }
    .modern-table td:last-child { border-radius: 0 10px 10px 0; }

    .btn-back 
    {
        background: #fff;
        color: #4e73df;
        border: 2px solid #4e73df;
        padding: 0.8rem 2rem;
        border-radius: 50px;
        font-weight: 600;
        transition: all 0.3s;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        margin-top: 2rem;
    }

    .btn-back:hover 
    {
        background: #4e73df;
        color: white;
        transform: scale(1.05);
        box-shadow: 0 5px 15px rgba(78, 115, 223, 0.3);
    }

    
    .avatar-circle 
    {
        width: 40px;
        height: 40px;
        background: var(--dark-grad);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        margin-right: 15px;
    }
</style>

<div class="container py-4">
    <div class="dashboard-header animate-in">
        <div>
            <h3><i class="fas fa-chart-line me-2"></i> Dashboard Admin</h3>
            <p class="mb-0">Analyse en temps réel des performances de l'équipe</p>
        </div>
        <i class="fas fa-shield-alt fa-3x opacity-25"></i>
    </div>

    
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="stat-card card-users">
                <div class="stat-title">Utilisateurs</div>
                <div class="stat-value"><?= $nbUsers ?></div>
                <div class="stat-icon"><i class="fas fa-users"></i></div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="stat-card card-tasks">
                <div class="stat-title">Tâches Totales</div>
                <div class="stat-value"><?= $nbTaches ?></div>
                <div class="stat-icon"><i class="fas fa-clipboard-list"></i></div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="stat-card card-pending">
                <div class="stat-title">En cours</div>
                <div class="stat-value"><?= $nbEnCours ?></div>
                <div class="stat-icon"><i class="fas fa-spinner fa-spin-hover"></i></div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="stat-card card-done">
                <div class="stat-title">Terminées</div>
                <div class="stat-value"><?= $nbTerminees ?></div>
                <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
            </div>
        </div>
    </div>

    <div class="glass-panel">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold mb-0">Objectif de complétion</h5>
            <span class="badge bg-primary rounded-pill"><?= $tauxCompletion ?>%</span>
        </div>
        <div class="progress">
            <div class="progress-bar progress-bar-striped progress-bar-animated bg-success" 
                 role="progressbar" 
                 style="width: <?= $tauxCompletion ?>%">
            </div>
        </div>
    </div>

    <div class="glass-panel">
        <h4 class="fw-bold mb-4"><i class="fas fa-user-tag text-primary me-2"></i> Répartition par Collaborateur</h4>
        <div class="table-responsive">
            <table class="table modern-table">
                <thead>
                    <tr>
                        <th>Membre</th>
                        <th class="text-center">Charge de travail</th>
                        <th class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tachesParUser as $u): ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="avatar-circle">
                                    <?= strtoupper(substr($u['prenom'], 0, 1)) ?>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark"><?= htmlspecialchars($u['prenom'].' '.$u['nom']) ?></div>
                                    <small class="text-muted">Collaborateur</small>
                                </div>
                            </div>
                        </td>
                        <td class="text-center">
                            <span class="badge bg-light text-primary border px-3 py-2 rounded-pill">
                                <?= $u['total'] ?> tâches
                            </span>
                        </td>
                        <td class="text-end">
                            <a href="#" class="btn btn-sm btn-outline-primary rounded-pill px-3">Détails</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="text-center">
        <a href="../taches/liste.php" class="btn-back">
            <i class="fas fa-arrow-left"></i>
            Retour 
        </a>
    </div>
</div>

