<?php
require '../config/database.php';
$pdo->prepare("DELETE FROM utilisateurs WHERE id=?")
->execute([$_GET['id']]);
header('Location: utilisateurs.php');
