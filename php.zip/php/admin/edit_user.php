<?php
require '../config/database.php';
$id=$_GET['id'];

if($_POST)
{
 $pdo->prepare
 (
 "UPDATE utilisateurs SET prenom=?,nom=?,role=? WHERE id=?"
 )->execute([$_POST['prenom'],$_POST['nom'],$_POST['role'],$id]);
 header('Location: utilisateurs.php');
}
$user=$pdo->query("SELECT * FROM utilisateurs WHERE id=$id")->fetch();
?>
<form method="post">
<input name="prenom" value="<?= $user['prenom'] ?>">
<input name="nom" value="<?= $user['nom'] ?>">
<select name="role">
<option <?= $user['role']=='Administrateur'?'selected':'' ?>>Administrateur</option>
<option <?= $user['role']=='Utilisateur simple'?'selected':'' ?>>Utilisateur simple</option>
</select>
<button>Modifier</button>
</form>
