<?php
require '../config/database.php';
if($_SESSION['user']['role']!='Administrateur') exit;
require '../includes/header.php';

$users=$pdo->query("SELECT * FROM utilisateurs")->fetchAll();
?>
<a href="add_user.php">Ajouter</a>
<table>
<?php foreach($users as $u): ?>
<tr>
<td><?= $u['prenom'] ?></td>
<td><?= $u['role'] ?></td>
<td>
<a href="edit_user.php?id=<?= $u['id'] ?>">Modifier</a>
<a href="delete_user.php?id=<?= $u['id'] ?>">Supprimer</a>
</td>
</tr>
<?php endforeach; ?>
</table>

