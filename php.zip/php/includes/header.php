<?php
if(!isset($_SESSION['user'])) header('Location: ../login.php');
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Partie design Boostraap</title>
<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,600&display=swap" rel="stylesheet">

</head>

