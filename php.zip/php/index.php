<?php require 'config/database.php'; ?>
<?php require 'includes/header.php'; ?>

<div class="container py-5">
    <div class="row mb-5 shadow-sm p-4 bg-white rounded-4 align-items-center">
        <div class="col-md-8">
            <h1 class="display-5 fw-bold text-dark">
                Bonjour, <span class="text-primary"><?= htmlspecialchars($_SESSION['user']['prenom']) ?></span> 👋
            </h1>
            <p class="lead text-muted">Ravi de vous revoir. Voici un aperçu de votre espace de travail.</p>
        </div>
        <div class="col-md-4 text-md-end">
            <span class="badge bg-light text-dark border px-3 py-2 rounded-pill">
                <i class="bi bi-shield-check text-success"></i> Statut : <?= $_SESSION['user']['role'] ?>
            </span>
        </div>
    </div>

    <div class="row g-4 justify-content-center">
        <div class="col-md-6">
            <div class="card h-100 border-0 shadow-sm border-start border-primary border-4 hover-card">
                <div class="card-body p-4">
                    <div class="icon-box bg-primary-soft mb-3">
                        <i class="bi bi-list-check fs-2 text-primary"></i>
                    </div>
                    <h4 class="card-title fw-bold">Gestion des Tâches</h4>
                    <p class="card-text text-muted">Consultez vos priorités, modifiez vos statuts et restez organisé au quotidien.</p>
                    <a href="taches/liste.php" class="btn btn-primary w-100 py-2 rounded-3 text-white fw-semibold" style="font-family: 'Poppins', sans-serif; font-style: italic;">
                        Ouvrir mes tâches <i class="bi bi-arrow-right ms-2"></i> 
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    body 
    { background-color: #f8f9fa; font-family: 'Inter', sans-serif; font-style: italic; }
    
    .hover-card 
    {
        transition: transform 0.3s ease, shadow 0.3s ease;
        border-radius: 1rem;
    }
    
    .hover-card:hover 
    {
        transform: translateY(-5px);
        box-shadow: 0 1rem 3rem rgba(0,0,0,.1) !important;
    }

    .bg-primary-soft 
    { 
        background-color: rgba(13, 110, 253, 0.1); 
        width: 60px; 
        height: 60px; 
        display: flex; 
        align-items: center; 
        justify-content: center; 
        border-radius: 12px; 
    }
    
    .btn-primary { background: linear-gradient(45deg, #0d6efd, #0b5ed7); border: none; }
</style>

