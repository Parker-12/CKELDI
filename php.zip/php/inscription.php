<?php
require 'config/database.php';


$erreur = '';
if(isset($_SESSION['erreur_inscription']))
{
    $erreur = $_SESSION['erreur_inscription'];
    unset($_SESSION['erreur_inscription']);
}

if($_SERVER['REQUEST_METHOD'] === 'POST')
{
    $prenom = trim($_POST['prenom']);
    $nom = trim($_POST['nom']);
    $email = trim($_POST['email']);
    $mot_de_passe = $_POST['mot_de_passe'];
    $confirmation = $_POST['confirmation'];

  
    if (empty($prenom) || empty($nom) || empty($email) || empty($mot_de_passe) || empty($confirmation))
    {
        $_SESSION['erreur_inscription'] = "Tous les champs sont obligatoires";
        header('Location: inscription.php');
        exit;
    }

    if($mot_de_passe !== $confirmation)
    {
        $_SESSION['erreur_inscription'] = "Les mots de passe ne correspondent pas";
        header('Location: inscription.php');
        exit;
    }

    if(strlen($mot_de_passe) < 6)
    {
        $_SESSION['erreur_inscription'] = "Le mot de passe doit contenir au moins 6 caractères";
        header('Location: inscription.php');
        exit;
    }

    
    $stmt = $pdo->prepare("SELECT id FROM utilisateurs WHERE email=?");
    $stmt->execute([$email]);
    if($stmt->fetch())
    {
        $_SESSION['erreur_inscription'] = "Cet email est déjà utilisé";
        header('Location: inscription.php');
        exit;
    }

   
    try 
    {
        $stmt = $pdo->prepare
        ("
            INSERT INTO utilisateurs (prenom, nom, email, mot_de_passe, role, date_creation)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute(
[
            $prenom,
            $nom,
            $email,
            sha1($mot_de_passe),
            'Utilisateur simple'
        ]);

        $_SESSION['succes_inscription'] = "Inscription réussie ! Vous pouvez maintenant vous connecter.";
        header('Location: login.php'); 
        exit;

    } 

    catch(PDOException $e) 
    {
        $_SESSION['erreur_inscription'] = "Erreur lors de l'inscription. Veuillez réessayer.";
        header('Location: inscription.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - TaskCenter</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * 
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body 
        {
            font-family: 'Inter', sans-serif;
            font-style: italic;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: url('https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=1920&q=80') center/cover;
            position: relative;
            padding: 20px;
        }

        body::before 
        {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4);
            z-index: 1;
        }

        .logo 
        {
            position: relative;
            z-index: 2;
            text-align: center;
            margin-bottom: 10px;
        }

        .logo h1 
        {
            font-size: 48px;
            font-weight: 700;
            color: white;
            margin-bottom: 0;
            letter-spacing: -1px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }

        .container 
        {
            position: relative;
            z-index: 2;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 50px 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 432px;
            animation: fadeInUp 0.6s ease;
        }

        @keyframes fadeInUp 
        {
            from 
            {
                opacity: 0;
                transform: translateY(30px);
            }
            to 
            {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .subtitle 
        {
            text-align: center;
            margin-bottom: 35px;
        }

        .subtitle h2 
        {
            font-size: 24px;
            font-weight: 600;
            color: #1c1e21;
            margin-bottom: 8px;
        }

        .subtitle p 
        {
            color: #64748b;
            font-size: 15px;
            font-weight: 400;
        }

        .form-group 
        {
            margin-bottom: 20px;
        }

        label 
        {
            display: block;
            margin-bottom: 8px;
            color: #334155;
            font-size: 14px;
            font-weight: 500;
        }

        input 
        {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: white;
            color: #1e293b;
        }

        input:focus 
        {
            outline: none;
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }

        input::placeholder 
        {
            color: #94a3b8;
        }

        button 
        {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 18px;
            font-family: 'Poppins', sans-serif;
            font-style: italic;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
            margin-top: 10px;
        }

        button:hover 
        {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(99, 102, 241, 0.5);
        }

        button:active 
        {
            transform: translateY(0);
        }

        .error-message 
        {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease, fadeOut 0.3s ease 3s forwards;
        }

        @keyframes slideDown 
        {
            from 
            {
                opacity: 0;
                transform: translateY(-10px);
            }
            to 
            {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeOut 
        {
            to 
            {
                opacity: 0;
                transform: translateY(-10px);
            }
        }

        .error-icon 
        {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        .footer-text 
        {
            text-align: center;
            margin-top: 25px;
            color: #64748b;
            font-size: 14px;
        }

        .footer-text a 
        {
            color: #6366f1;
            text-decoration: none;
            font-weight: 500;
        }

        .footer-text a:hover 
        {
            text-decoration: underline;
        }

        .password-requirements 
        {
            font-size: 11px;
            color: #64748b;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="subtitle">
           <h2>Créer un compte</h2>
           <p>C'est simple et rapide.</p>
        </div>

        <?php if(!empty($erreur)): ?>
        <div class="error-message">
            <svg class="error-icon" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($erreur) ?></span>
        </div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
            <div class="form-group">
                <input type="text" id="prenom" name="prenom" placeholder="Prénom" required autocomplete="off">
            </div>

            <div class="form-group">
                <input type="text" id="nom" name="nom" placeholder="Nom" required autocomplete="off">
            </div>

            <div class="form-group">
                <input type="email" id="email" name="email" placeholder="Adresse e-mail" required autocomplete="off">
            </div>

            <div class="form-group">
                <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="Nouveau mot de passe" required autocomplete="new-password">
                <div class="password-requirements">Minimum 6 caractères</div>
            </div>

            <div class="form-group">
                <input type="password" id="confirmation" name="confirmation" placeholder="Confirmer le mot de passe" required autocomplete="new-password">
            </div>

            <button type="submit">S'inscrire</button>

            <div class="footer-text">
                <a href="login.php">Vous avez déjà un compte ?</a>
            </div>
        </form>
    </div>

    <script>
        
        const errorMsg = document.querySelector('.error-message');
        
        if(errorMsg) 
        {
            setTimeout(() =>
            {
                errorMsg.remove();
            }, 3000);
        }
    </script>
</body>
</html>