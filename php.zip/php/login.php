<?php

require 'config/database.php';

$erreur = '';
if(isset($_SESSION['erreur_login']))
{
    $erreur = $_SESSION['erreur_login'];
    unset($_SESSION['erreur_login']); 
}

$succes = '';
if(isset($_SESSION['succes_inscription']))
{
    $succes = $_SESSION['succes_inscription'];
    unset($_SESSION['succes_inscription']);
}

if($_SERVER['REQUEST_METHOD'] === 'POST')
{
    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email=? AND mot_de_passe=?");
    $stmt->execute([$_POST['email'], sha1($_POST['mot_de_passe'])]);
    $user = $stmt->fetch();

    if($user){
        $_SESSION['user'] = $user;
        header('Location: index.php');
        exit;
    } 
    else 
    {
        
        $_SESSION['erreur_login'] = "Email ou mot de passe incorrect";
        header('Location: login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Tâches</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * 
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body 
        {
            font-family: 'Inter', sans-serif;
            font-style: italic;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background:  url('https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?w=1920&q=80') center/cover;
            position: relative;
        }

        body::before 
        {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4);
            z-index: 1;
        }

        .container 
        {
            position: relative;
            z-index: 2;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 50px 40px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 420px;
            animation: fadeInUp 0.6s ease;
        }

        @keyframes fadeInUp 
        {
            from 
            {
                opacity: 0;
                transform: translateY(30px);
            }
            to 
            {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .logo 
        {
            text-align: center;
            margin-bottom: 35px;
        }

        .logo h1 
        {
            font-size: 28px;
            font-weight: 700;
            color: #0f62fe;
            margin-bottom: 8px;
        }

        .logo p 
        {
            color: #64748b;
            font-size: 14px;
            font-weight: 400;
        }

        .form-group 
        {
            margin-bottom: 25px;
        }

        label 
        {
            display: block;
            margin-bottom: 8px;
            color: #334155;
            font-size: 14px;
            font-weight: 500;
        }

        input 
        {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.3s ease;
            background: white;
            color: #1e293b;
        }

        input:focus 
        {
            outline: none;
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }

        input::placeholder 
        {
            color: #94a3b8;
        }

        button 
        {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            font-style: italic;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
        }


        button:hover 
        {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(99, 102, 241, 0.5);
        }

        button:active 
        {
            transform: translateY(0);
        }

        .error-message 
        {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease, fadeOut 0.3s ease 3s forwards;
        }

        .success-message 
        {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            color: #16a34a;
            padding: 12px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease, fadeOut 0.3s ease 3s forwards;
        }

        @keyframes slideDown 
        {
            from 
            {
                opacity: 0;
                transform: translateY(-10px);
            }
            to 
            {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeOut 
        {
            to 
            {
                opacity: 0;
                transform: translateY(-10px);
            }
        }

        .error-icon, .success-icon 
        {
            width: 20px;
            height: 20px;
            flex-shrink: 0;
        }

        .footer-text 
        {
            text-align: center;
            margin-top: 25px;
            color: #64748b;
            font-size: 13px;
        }

        .footer-text a 
        {
            color: #6366f1;
            text-decoration: none;
            font-weight: 500;
        }

        .footer-text a:hover 
        {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
           <h1>TaskCenter</h1>
           <p>Centre de gestion des tâches</p>
        </div>

        <?php if(!empty($erreur)): ?>
        <div class="error-message">
            <svg class="error-icon" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($erreur) ?></span>
        </div>
        <?php endif; ?>

        <?php if(!empty($succes)): ?>
        <div class="success-message">
            <svg class="success-icon" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
            <span><?= htmlspecialchars($succes) ?></span>
        </div>
        <?php endif; ?>

        <form method="post" autocomplete="off">
            <div class="form-group">
                <label for="email">Adresse e-mail</label>
                <input type="email" id="email" name="email" placeholder="name@email.com" required autocomplete="off">
            </div>

            <div class="form-group">
                <label for="mot_de_passe">Mot de passe</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="••••••••" required autocomplete="new-password">
            </div>

            <button type="submit">Se connecter</button>

            <div class="footer-text">
                Pas encore de compte ? <a href="inscription.php">Créer un nouveau compte</a>
            </div>
        </form>
    </div>

    <script>
     
        const errorMsg = document.querySelector('.error-message');
        const successMsg = document.querySelector('.success-message');
        
        if(errorMsg) 
        {
            setTimeout(() => 
            {
                errorMsg.remove();
            }, 3000);
        }
        
        if(successMsg) 
        {
            setTimeout(() => 
            {
                successMsg.remove();
            }, 3000);
        }
    </script>
</body>
</html>