-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 31 déc. 2025 à 18:38
-- Version du serveur : 10.4.20-MariaDB
-- Version de PHP : 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_taches`
--

-- --------------------------------------------------------

--
-- Structure de la table `taches`
--

CREATE TABLE `taches` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `statut` enum('En cours','Terminée') COLLATE utf8mb4_unicode_ci DEFAULT 'En cours',
  `utilisateur_id` int(11) NOT NULL,
  `date_creation` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `taches`
--

INSERT INTO `taches` (`id`, `titre`, `description`, `statut`, `utilisateur_id`, `date_creation`) VALUES
(1, 'Développement du module d’authentification', 'Implémentation de la connexion sécurisée, gestion des sessions et déconnexion', 'Terminée', 1, '2025-12-25 23:07:47'),
(2, 'Gestion des utilisateurs (Admin)', 'Ajout, modification, suppression des utilisateurs et attribution des rôles', 'Terminée', 1, '2025-12-25 23:07:47'),
(3, 'Gestion des tâches utilisateur', 'Création, modification, suppression et validation des tâches personnelles', 'En cours', 2, '2025-12-25 23:07:47'),
(4, 'Recherche et filtrage des tâches', 'Mise en place de la recherche par mot-clé et filtrage par statut', 'En cours', 1, '2025-12-25 23:07:47'),
(5, 'Tests et validation de l’application', 'Vérification des droits d’accès selon les rôles et correction des anomalies', 'Terminée', 1, '2025-12-25 23:07:47'),
(6, 'Analyse des besoins', 'Recueil et analyse des besoins des utilisateurs', 'Terminée', 2, '2025-12-26 22:26:05'),
(7, 'Conception UML', 'Diagrammes de cas d’utilisation et de classes', 'En cours', 2, '2025-12-26 22:26:05'),
(8, 'Développement backend', 'Implémentation PHP et MySQL', 'En cours', 2, '2025-12-26 22:26:05'),
(33, 'Supervision du tableau de bord admin', 'Analyse des statistiques globales et suivi des performances des utilisateurs', 'En cours', 40, '2025-12-31 17:32:28'),
(34, 'Validation des comptes utilisateurs', 'Vérification et activation des comptes nouvellement créés', 'Terminée', 40, '2025-12-31 17:33:30'),
(35, 'Mise à jour des tâches utilisateur', 'Modification du statut et mise à jour des informations des tâches assignées', 'En cours', 41, '2025-12-31 17:35:25'),
(36, 'Documentation technique', 'Rédaction de la documentation utilisateur et technique de l’application', 'Terminée', 41, '2025-12-31 17:36:17');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `taches`
--
ALTER TABLE `taches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_utilisateur` (`utilisateur_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `taches`
--
ALTER TABLE `taches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `taches`
--
ALTER TABLE `taches`
  ADD CONSTRAINT `fk_utilisateur` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
