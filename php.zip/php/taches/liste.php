<?php
require '../config/database.php';
require '../includes/header.php';


if (!isset($_SESSION['user'])) 
{
    header('Location: ../login.php');
    exit;
}


$taches = [];


$search = $_GET['search'] ?? '';
$statut = $_GET['statut'] ?? '';


$sql = "SELECT * FROM taches WHERE 1=1";
$params = [];


if ($_SESSION['user']['role'] !== 'Administrateur') 
{
    $sql .= " AND utilisateur_id = ?";
    $params[] = $_SESSION['user']['id'];
}


if (!empty($search)) 
{
    $sql .= " AND titre LIKE ?";
    $params[] = "%$search%";
}

if (!empty($statut)) 
{
    $sql .= " AND statut = ?";
    $params[] = $statut;
}


$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$taches = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Tâches</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root 
        {
            --primary-gradient: linear-gradient(135deg, #0f62fe 0%, #002d9c 100%);
            --success-gradient: linear-gradient(135deg, #198754 0%, #146c43 100%);
            --danger-gradient: linear-gradient(135deg, #bb2d3b 0%, #842029 100%);
            --dark-bg: #1a1d29;
            --card-bg: #ffffff;
            --shadow-lg: 0 10px 40px rgba(0,0,0,0.1);
        }

        body 
        {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-style: italic;
            min-height: 100vh;
        }

      
        .navbar-premium 
        {
            background: var(--dark-bg);
            box-shadow: 0 4px 20px rgba(4, 51, 222, 0.3);
            padding: 1rem 0;
        }

        .navbar-brand 
        {
            font-size: 1.5rem;
            font-weight: 700;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .user-info 
        {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-avatar 
        {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }

        
        .premium-container 
        {
            max-width: 100%;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        
        .header-actions-row 
        {
            display: flex;
            justify-content: space-between; 
            align-items: center;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        
        .btn-premium 
        {
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            border: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .btn-premium-primary 
        {
            background: var(--primary-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-premium-success 
        {
            background: var(--success-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(17, 153, 142, 0.4);
        }

        .btn-premium-danger 
        {
            background: var(--danger-gradient);
            color: white;
        }

        .btn-premium:hover 
        {
            transform: translateY(-2px);
            filter: brightness(1.1);
            color: white;
        }

        .filter-card 
        {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-lg);
            width: 50%;
            margin-left: auto;
            margin-right: auto;
        }

        .form-control-premium 
        {
            border: 2px solid #e0e7ff;
            border-radius: 12px;
            padding: 0.75rem 1rem;
            transition: all 0.3s ease;
        }

        
        .table-card 
        {
            background: var(--card-bg);
            border-radius: 20px;
            padding: 1rem;
            box-shadow: var(--shadow-lg);
            overflow-x: auto;
        }

        .table-premium thead th 
        {
            background: #2563eb;
            color: #f9fafb;
            padding: 1rem;
            text-transform: uppercase;
            font-size: 0.85rem;
            border: none;
        }

        .table-premium tbody td 
        {
            padding: 1rem;
            vertical-align: middle;
            border-bottom: 1px solid #eee;
        }

        
        .badge-premium 
        {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 600;
        }

        .badge-success-premium { background: var(--success-gradient); color: white; }
        .badge-warning-premium { background: linear-gradient(135deg, #7c3aed 0%, #5b21b6 100%); color: white; }

        
        .action-btn 
        {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border: none;
            transition: all 0.3s ease;
            margin: 0 0.2rem;
            color: white;
            text-decoration: none;
        }

        .action-btn-success { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        .action-btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .action-btn-danger { background: linear-gradient(135deg, #eb3349 0%, #f45c43 100%); }

        .footer-premium 
        {
            background: var(--dark-bg);
            color: white;
            padding: 3rem 0;
            margin-top: 4rem;
        }

        .footer-title 
        {
            font-weight: 700;
            margin-bottom: 1rem;
            background: var(--primary-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .empty-state { text-align: center; padding: 3rem; color: #a0aec0; }
    </style>
</head>
<body>

<nav class="navbar navbar-premium navbar-dark">
    <div class="container-fluid px-4">
        <span class="navbar-brand"><i class="fas fa-tasks"></i> TaskCenter</span>
        <div class="user-info">
            <div class="user-avatar"><?= strtoupper(substr($_SESSION['user']['prenom'], 0, 1)) ?></div>
            <div class="text-white d-none d-md-block">
                <small class="d-block opacity-75">Bienvenue</small>
                <strong><?= htmlspecialchars($_SESSION['user']['prenom']) ?></strong>
            </div>
            <a href="../logout.php" class="btn btn-premium-danger btn-sm">
                <i class="fas fa-sign-out-alt"></i> Déconnexion
            </a>
        </div>
    </div>
</nav>

<div class="premium-container">

    <div class="filter-card">
        <form method="get">
            <div class="header-actions-row">
                <div class="action-left">
                    <a href="ajouter.php" class="btn-premium btn-premium-success">
                        <i class="fas fa-plus"></i> Nouvelle tâche
                    </a>
                </div>

                <div class="action-right">
                    <?php if ($_SESSION['user']['role'] === 'Administrateur'): ?>
                        <a href="../admin/dashboard.php" class="btn-premium btn-premium-primary">
                            <i class="fas fa-chart-line"></i> Tableau de bord
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row g-3 align-items-end">
                <div class="col-md-5">
                    <label class="form-label fw-bold text-muted small"><i class="fas fa-search"></i> Rechercher</label>
                    <input type="text" name="search" class="form-control form-control-premium" placeholder="Titre de la tâche..." value="<?= htmlspecialchars($search) ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label fw-bold text-muted small"><i class="fas fa-filter"></i> Statut</label>
                    <select name="statut" class="form-control form-control-premium">
                        <option value="">Tous les statuts</option>
                        <option value="En cours" <?= $statut === 'En cours' ? 'selected' : '' ?>>En cours</option>
                        <option value="Terminée" <?= $statut === 'Terminée' ? 'selected' : '' ?>>Terminée</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <button type="submit" class="btn-premium btn-premium-primary w-100 justify-content-center">
                        <i class="fas fa-filter"></i> Filtrer
                    </button>
                </div>
            </div>
        </form>
    </div>

    <div class="table-card">
        <div class="table-responsive">
            <table class="table table-premium">
                <thead>
                    <tr>
                        <th><i class="fas fa-heading"></i> titre</th>
                        <th><i class="fas fa-align-left"></i> description</th>
                        <th class="text-center"><i class="fas fa-flag"></i> statut</th>
                        <th class="text-center"><i class="fas fa-user"></i> utilisateur_id</th>
                        <th class="text-center"><i class="fas fa-calendar"></i> date_creation</th>
                        <th class="text-center"><i class="fas fa-cog"></i> Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (count($taches) === 0): ?>
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="fas fa-inbox"></i>
                                <h4>Aucune tâche trouvée</h4>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($taches as $t): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($t['titre']) ?></strong></td>
                            <td><?= htmlspecialchars($t['description']) ?></td>
                            <td class="text-center">
                                <span class="badge badge-premium <?= $t['statut'] === 'Terminée' ? 'badge-success-premium' : 'badge-warning-premium' ?>">
                                    <i class="fas fa-<?= $t['statut'] === 'Terminée' ? 'check-circle' : 'clock' ?>"></i>
                                    <?= htmlspecialchars($t['statut']) ?>
                                </span>
                            </td>
                            <td class="text-center"><span class="badge bg-secondary">#<?= htmlspecialchars($t['utilisateur_id']) ?></span></td>
                            <td class="text-center"><small class="text-muted"><?= date('d/m/Y', strtotime($t['date_creation'])) ?></small></td>
                            <td class="text-center">
                                <?php if ($t['statut'] !== 'Terminée'): ?>
                                    <a href="terminer.php?id=<?= $t['id'] ?>" class="action-btn action-btn-success" title="Terminer"><i class="fas fa-check"></i></a>
                                <?php endif; ?>
                                <a href="modifier.php?id=<?= $t['id'] ?>" class="action-btn action-btn-primary" title="Modifier"><i class="fas fa-edit"></i></a>
                                <a href="supprimer.php?id=<?= $t['id'] ?>" class="action-btn action-btn-danger" onclick="return confirm('Supprimer ?')" title="Supprimer"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<footer class="footer-premium">
    <div class="container">
        <div class="row text-center text-md-start align-items-center">
            <div class="col-md-4 mb-3 mb-md-0">
                <h6 class="footer-title"><i class="fas fa-code"></i> Projet PHP & MySQL</h6>
                <p class="mb-0 small text-secondary">Application moderne de gestion des tâches</p>
            </div>
            <div class="col-md-4 text-center mb-3 mb-md-0">
                <p class="mb-0 small"><i class="far fa-copyright"></i> <?= date('Y') ?> — Tous droits réservés</p>
            </div>
            <div class="col-md-4 text-center text-md-end">
                <p class="mb-0 small"><i class="fas fa-code-branch text-primary"></i> Conçu et développé  par <span class="fw-bold" style="background: var(--primary-gradient); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;"><strong>Sans Limite</strong></span></p>
                <div class="mt-2">
                    <span class="badge bg-light text-dark me-1"><i class="fab fa-php"></i> PHP</span>
                    <span class="badge bg-light text-dark me-1"><i class="fas fa-database"></i> MySQL</span>
                    <span class="badge bg-light text-dark"><i class="fab fa-bootstrap"></i> Bootstrap</span>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>