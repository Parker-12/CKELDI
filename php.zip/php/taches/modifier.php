<?php
require '../config/database.php';
require '../includes/header.php';


if (!isset($_SESSION['user'])) 
{
    header('Location: ../login.php');
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) 
{
    header('Location: liste.php');
    exit;
}


$sql = "SELECT * FROM taches WHERE id = ?";
$params = [$id];


if ($_SESSION['user']['role'] !== 'Administrateur') 
{
    $sql .= " AND utilisateur_id = ?";
    $params[] = $_SESSION['user']['id'];
}

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tache = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$tache) 
{
    header('Location: liste.php');
    exit;
}


$utilisateurs = [];
if ($_SESSION['user']['role'] === 'Administrateur') 
{
    $stmtUsers = $pdo->query("SELECT id, prenom, nom FROM utilisateurs");
    $utilisateurs = $stmtUsers->fetchAll(PDO::FETCH_ASSOC);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{

    $titre = trim($_POST['titre'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $statut = $_POST['statut'] ?? 'En cours';

    if ($_SESSION['user']['role'] === 'Administrateur') 
    {
        $utilisateur_id = $_POST['utilisateur_id'] ?? null;
    } 
    else 
    {
        $utilisateur_id = $_SESSION['user']['id'];
    }

    if (!empty($titre) && !empty($description) && !empty($utilisateur_id)) 
    {

        $stmt = $pdo->prepare
        (
            "UPDATE taches 
             SET titre = ?, description = ?, statut = ?, utilisateur_id = ?
             WHERE id = ?"
        );

        $stmt->execute(
[
            $titre,
            $description,
            $statut,
            $utilisateur_id,
            $id
        ]);

        header('Location: liste.php');
        exit;
    }

    $erreur = "Tous les champs sont obligatoires";
}
?>

<style>
    body
    {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-style: italic;
    }

    .task-form-container 
    {
        max-width: 800px;
        margin: 20px auto;
        padding: 0 20px;
    }

    .form-card 
    {
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07), 0 1px 3px rgba(0, 0, 0, 0.06);
        overflow: hidden;
    }

    .form-header 
    {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 32px;
        color: white;
    }

    .form-header h3 
    {
        margin: 0;
        font-size: 28px;
        font-weight: 600;
        text-align: center;
    }

    .form-body 
    {
        padding: 40px;
    }

    .alert-custom 
    {
        background: #fee;
        border: 1px solid #fcc;
        color: #c33;
        padding: 16px 20px;
        border-radius: 10px;
        margin-bottom: 30px;
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 14px;
    }

    .form-group-custom 
    {
        margin-bottom: 28px;
    }

    .form-label-custom 
    {
        display: block;
        font-weight: 600;
        color: #2d3748;
        margin-bottom: 10px;
        font-size: 14px;
        letter-spacing: 0.3px;
    }

    .form-control-custom 
    {
        width: 100%;
        padding: 14px 16px;
        border: 2px solid #e2e8f0;
        border-radius: 10px;
        font-size: 15px;
        color: #2d3748;
        transition: all 0.3s ease;
        background: #ffffff;
        font-family: inherit;
    }

    .form-control-custom:focus 
    {
        outline: none;
        border-color: #667eea;
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }

    .form-control-custom::placeholder 
    {
        color: #a0aec0;
    }

    textarea.form-control-custom 
    {
        resize: vertical;
        min-height: 140px;
        line-height: 1.6;
    }

    select.form-control-custom 
    {
        cursor: pointer;
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23667eea' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 16px center;
        padding-right: 45px;
    }

    .form-actions 
    {
        display: flex;
        gap: 12px;
        margin-top: 36px;
        padding-top: 24px;
        border-top: 1px solid #e2e8f0;
    }

    .btn-custom 
    {
        padding: 14px 32px;
        border: none;
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        text-decoration: none;
        display: inline-block;
        text-align: center;
    }

    .btn-primary-custom 
    {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    }

    .btn-primary-custom:hover 
    {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(102, 126, 234, 0.4);
    }

    .btn-secondary-custom 
    {
        background: #e2e8f0;
        color: #4a5568;
    }

    .btn-secondary-custom:hover 
    {
        background: #cbd5e0;
        transform: translateY(-1px);
    }

    .status-badge 
    {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        margin-left: 8px;
    }

    .status-en-cours 
    {
        background: #fef3c7;
        color: #92400e;
    }

    .status-terminee 
    {
        background: #d1fae5;
        color: #065f46;
    }

    @media (max-width: 768px) 
    {
        .form-body 
        {
            padding: 24px;
        }

        .form-header 
        {
            padding: 24px;
        }

        .form-header h3 
        {
            font-size: 22px;
        }

        .form-actions 
        {
            flex-direction: column;
        }

        .btn-custom 
        {
            width: 100%;
        }
    }
</style>

<div class="task-form-container">
    <div class="form-card">
        
        <div class="form-header">
            <h3>
                Modifier la tâche
            </h3>
        </div>

        <div class="form-body">

            <?php if (!empty($erreur)): ?>
                <div class="alert-custom">
                    <span>⚠️</span>
                    <span><?= htmlspecialchars($erreur) ?></span>
                </div>
            <?php endif; ?>

            <form method="post">

                <div class="form-group-custom">
                    <label class="form-label-custom">Titre</label>
                    <input type="text" name="titre" class="form-control-custom" 
                           value="<?= htmlspecialchars($tache['titre']) ?>" 
                           placeholder="Ex: Finaliser le rapport mensuel" required>
                </div>

                <div class="form-group-custom">
                    <label class="form-label-custom">Description</label>
                    <textarea name="description" class="form-control-custom" rows="8" 
                              placeholder="Décrivez en détail la tâche à accomplir..." required><?= htmlspecialchars($tache['description']) ?></textarea>
                </div>

                <div class="form-group-custom">
                    <label class="form-label-custom">Statut</label>
                    <select name="statut" class="form-control-custom">
                        <option value="En cours" <?= $tache['statut'] === 'En cours' ? 'selected' : '' ?>>En cours</option>
                        <option value="Terminée" <?= $tache['statut'] === 'Terminée' ? 'selected' : '' ?>>Terminée</option>
                    </select>
                </div>

                <?php if ($_SESSION['user']['role'] === 'Administrateur'): ?>
                    <div class="form-group-custom">
                        <label class="form-label-custom">Assigner à</label>
                        <select name="utilisateur_id" class="form-control-custom" required>
                            <?php foreach ($utilisateurs as $u): ?>
                                <option value="<?= $u['id'] ?>"
                                    <?= $u['id'] == $tache['utilisateur_id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($u['prenom'].' '.$u['nom']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php else: ?>
                    <input type="hidden" name="utilisateur_id" value="<?= $_SESSION['user']['id'] ?>">
                <?php endif; ?>

                <div class="form-actions">
                    <button type="submit" class="btn-custom btn-primary-custom">Mettre à jour</button>
                    <a href="liste.php" class="btn-custom btn-secondary-custom">Annuler</a>
                </div>

            </form>
        </div>

    </div>
</div>

