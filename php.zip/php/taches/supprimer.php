<?php
require '../config/database.php';
if($_SESSION['user']['role']!='Administrateur')
{
 $s=$pdo->prepare("DELETE FROM taches WHERE id=? AND utilisateur_id=?");
 $s->execute([$_GET['id'],$_SESSION['user']['id']]);
}
else
{
 $pdo->prepare("DELETE FROM taches WHERE id=?")
 ->execute([$_GET['id']]);
}
header('Location: liste.php');
