<?php
require '../config/database.php';
$pdo->prepare
(
"UPDATE taches SET statut='Terminée' WHERE id=?"
)->execute([$_GET['id']]);
header('Location: liste.php');
